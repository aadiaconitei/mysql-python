<?php
function getConnection() {
	$bbdd = 'mysql:host=localhost;dbname=anuntbew2020;charset=utf8';
	$userdb = 'bew20'; 
	$pass = 'bew20';
	try {
    	$connection = new PDO($bbdd, $userdb, $pass);
    	return $connection;
	} catch (PDOException $e) {
	    echo 'Eroare conexiune DB: ';// . $e->getMessage();
	}
}
?>
